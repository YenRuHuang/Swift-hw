

import UIKit


    class ViewController: UIViewController {
    @IBOutlet weak var display: UILabel!

    var operands = [Double]()
    var operatorSymbol: String?
    var isTypingNumber = false
    var displayValue: Double {
    get {
        return Double(display.text!)!
        }
        set {
            if newValue == floor(newValue) {
                display.text = "\(Int(newValue))"
            } else {
                display.text = "\(newValue)"
            }
            isTypingNumber = false
        }
    }

    @IBAction func appeneNumber(_ sender: UIButton) {
        let digit = sender.currentTitle!
        if isTypingNumber {
            display.text! += digit
        } else {
            display.text = digit
            isTypingNumber = true
        }
    }
    
    @IBAction func doubleZeroButtonClicked(_ sender: UIButton) {
        let currentText = self.display.text ?? "0"
       
        guard currentText != "0" && !currentText.contains(".") else {
            return
        }
        self.display.text = currentText + "00"
    }

       @IBAction func clearButtonClicked(_ sender: UIButton) {
      
        self.display.text = "0"
    }

    
    @IBAction func operateNowBottonClicked(_ sender: UIButton) {
        isTypingNumber = false
        operatorSymbol = sender.currentTitle!
        operands.append(displayValue)
    }

    @IBAction func equalButtonClicked(_ sender: AnyObject) {
        if operatorSymbol != nil {
            isTypingNumber = false
            operands.append(displayValue)
            
            switch operatorSymbol! {
            case "+":
                execute() { $0 + $1 }
            case "-":
                execute() { $1 - $0 }
            case "*":
                execute() { $0 * $1 }
            case "/":
                execute() { $1 / $0 }
            default:
                break
            }
            print("\(operands)" + operatorSymbol!)
        }
    }
    
    
    func execute(_ operation: (Double, Double) -> Double) {
        displayValue = operation(operands.removeLast(), operands.removeLast())
        operands.append(displayValue)
    }
    
    
    @IBAction func perBottonClicked(_ sender: UIButton) {
        isTypingNumber = false
        displayValue = displayValue * 0.01
    }
    
    
    @IBAction func posNegBottonClicked(_ sender: UIButton) {
        isTypingNumber = false
        displayValue = -displayValue
        
    }
    
}
